// AtendeLab - Scripts gerais
